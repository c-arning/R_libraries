### visRble

viscols<-c("#FFFFFF", "#00193C", "#ECEDEE", "#7FAF0D", "#284BAA", "#01CFCE", "#FF8700", "#BED583", "#5F5C73", "#80E7E6")

pn_bigmark<-function(x){prettyNum(x,big.mark = ".",decimal.mark = ",")}

pn_percent<-function(x,k){paste(round(x*100,k),"%") }

uni_fun<-function(x){length(unique(x))}

